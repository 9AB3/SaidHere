THE WALL UI ASSET KIT

These PNGs were split from the generated UI asset sheet and have transparent backgrounds.

Recommended app usage:
- plaque.png: Home/NFC hero (the existing standalone plaque PNG in the repo is higher quality if preferred)
- walls_found_header.png: section header
- wall_location_card.png: example location label
- note_white_blank.png / note_brown_blank.png / note_black_blank.png: post card backgrounds
- writing_unlocked_red.png: 15-minute access banner
- composer_write_it.png: composer panel reference/asset
- locked_write_panel.png: locked-state write control
- tape_*.png: decorative overlays
- arrow_left.png / arrow_right.png / refresh.png / menu_dots.png: distressed controls

For dynamic user text, use the blank note/tape assets as backgrounds and render text in Flutter on top.
